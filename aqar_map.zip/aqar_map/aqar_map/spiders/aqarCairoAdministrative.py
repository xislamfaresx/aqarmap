import scrapy

from ..items import AqarMapItem


class AqarcairoadministrativeSpider(scrapy.Spider):
    name = 'aqarCairoAdministrative'
    #allowed_domains = ['https://aqarmap.com.eg/ar/for-sale/administrative/cairo/?photos=0&unitOnly=0']
    #start_urls = ['https://aqarmap.com.eg/ar/for-rent/administrative/cairo/']
    start_urls = ['https://aqarmap.com.eg/ar/for-rent/commercial/cairo/']

    def parse(self, response):

    #     nextAds = response.xpath('//a[@class="card-details-title"]/@href').extract()
    #     for x in nextAds:
    #         y = 'https://aqarmap.com.eg' + str(x)
    #         yield response.follow(url=y, callback=self.get_info)
    #
    #
    # def get_info(self, response):
        #unit = response.css('.first+ li span::text').extract()
        type = response.css('.fa-building+ .text-inherit::text').extract()
        location2 = response.css('li:nth-child(5) span::text').extract()
        location1 = response.css('.address .text-inherit::text').extract()
        #city = response.css('li:nth-child(4) span::text').extract()
        sizeAria = response.css('#listing-title-container label:nth-child(5)::text').extract()
        price = response.css('.listing-price-content .integer::text').extract()
        bathroom = response.css('#listing-title-container label:nth-child(4)::text').extract()
        bedroom = response.css('#listing-title-container label:nth-child(3)::text').extract()

        items = AqarMapItem()
        items['unit'] = "عقار للإيجار"
        items['type'] = type
        items['location2'] = location2
        items['location1'] = location1
        items['city'] = "القاهرة الكبرى"
        items['sizeAria'] = sizeAria
        items['price'] = price
        items['bathroom'] = bathroom
        items['bedroom'] = bedroom

        yield items

        pass

        nextAds = response.xpath("//h2/a/@href").extract()
        for x in nextAds:
            yield response.follow('https://aqarmap.com.eg' + x, callback=self.parse)

        next_page_url = response.xpath('.//*[@id="te-next-search-result-page"]/@href').extract_first()
        absolute_next_page_url = response.urljoin(next_page_url)
        yield scrapy.Request(url=absolute_next_page_url, callback=self.parse)